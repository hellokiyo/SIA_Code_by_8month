/*입력한 배열의 합을 구하는 프로그램을 작성하시오.
 - 입력 : 4 9 3 50 => 문자열로 입력됨
 - 출력 : 64*/
public class test1 {

	public static void main(String[] args) {


	}

}
