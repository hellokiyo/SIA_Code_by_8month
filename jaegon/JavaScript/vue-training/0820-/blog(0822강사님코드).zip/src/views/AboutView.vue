<template>

  <div>
    <h1>정보 화면</h1>
  </div>
  
</template>

<script setup>

</script>

<style>

</style>
